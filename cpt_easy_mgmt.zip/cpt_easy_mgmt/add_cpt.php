<div class="wrap">
    <h1>Add/Edit new Post type.</h1>
    <?php
    /*
    * Create new Post types
    */
    if (isset($_POST['ctp_name'])) {
        $cpt_name = (strtolower(sanitize_text_field($_POST['ctp_name'])));


        $current_post_type = get_option('cpt_easy_mgmt');
        /*
         * if this is first post type, create taxonomy option field with empty array
         */
        if ($current_post_type == '') {
            $new_cpt = explode(',', $cpt_name);
            if (update_option('cpt_easy_mgmt', $new_cpt)) {
                update_option('cpt_easy_mgmt_taxonomy', array());
                echo "<h2>First cusotm Post type added</h2>";
            }
        }
        /*
         * if not first custom post type.
         */
        else {

            array_push($current_post_type, $cpt_name);

            if (update_option('cpt_easy_mgmt', $current_post_type)) {
                echo "<h2>New cusotm Post type added</h2>";
            }
        }

    flush_rewrite_rules(true);
    }

    ?>
    <table class="widefat">
        <form action="" method="post">
            <tr>
                <td>Post Type Name</td>

                <td><input type="text" name="ctp_name" required=""></td>
            </tr>

            <tr>


                <td colspan="2"><input type="submit" value="Add"></td>
            </tr>

        </form>
    </table>
</div>