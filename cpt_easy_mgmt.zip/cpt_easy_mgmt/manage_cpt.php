<?php
/*
 * post and taxonomy management
 */

?>
<div class="wrap">
    <h1>Custom Post Types Easy Management</h1>

    <?php
    /*
     * Get all taxonomies
     */
    function cpt_taxonomies()
    {
        return get_option('cpt_easy_mgmt_taxonomy');

    }
    /*
         * Get all post types
         */
    function cpt_post_types()
    {
        return get_option('cpt_easy_mgmt');

    }

    /*
     * delete a current taxonomy
     */
    if (isset($_GET['taxon']) && isset($_GET['act']) && $_GET['act'] == "del_taxon") {

        $taxonomies = cpt_taxonomies();
        //print_r($taxonomies);
        unset($taxonomies[$_GET['taxon']]);
        update_option('cpt_easy_mgmt_taxonomy', $taxonomies);
        echo "<h2> Taxonomy has been deleted</h2>";


    }
    /*
    * Create new taxonomy
    */
    if (isset($_GET['cpt']) && isset($_GET['act'])) {

        $taxonomies = cpt_taxonomies();
        if (isset($_POST['cpt_taxonomy'])) {
            $cpt_taxonomies = strtolower($_POST['cpt_taxonomy']);

            $new_taxon = array($_GET['cpt'] => $cpt_taxonomies);


            array_push($taxonomies, $new_taxon);
            if (update_option('cpt_easy_mgmt_taxonomy', $taxonomies)) {
            }
        }


        ?>
        <h2>Current taxonomies</h2>
        <table class="widefat" style="width:400px">
            <?php
            foreach ($taxonomies as $parent_key => $taxonomy) {
                foreach ($taxonomy as $key => $taxon) {

                    if ($key == $_GET['cpt']) {
                        ?>
                        <tr>
                            <td>
                                <?php
                                echo $taxon; ?></td>
                            <td>
                                <a href="admin.php?page=cpt_easy_mgmt/manage_cpt.php&taxon=<?php echo $parent_key; ?>&act=del_taxon">delete</a>
                            </td>
                        </tr>
                    <?php
                    }
                }
            }


            ?>
        </table>
        <table class="widefat">
            <form action="" method="post">

                <h2>Add New Taxonomy </h2>
                <tr>
                    <td>Taxonomy Name:<input type="text" name="cpt_taxonomy"></td>
                </tr>
                <tr>


                    <td colspan="2"><input type="submit" value="Add"></td>
                </tr>

            </form>
        </table>
    <?php }

    /*
        * delete custom post type
        */
    if (isset($_GET['act']) && $_GET['act'] == 'del_cpt') {


        $cpts = get_option('cpt_easy_mgmt');

        if (($key = array_search($_GET['cpt'], $cpts)) !== false) {
            unset($cpts[$key]);
            update_option('cpt_easy_mgmt', $cpts);
            echo "<h2>" . $_GET['cpt'] . " post type has been deleted</h2>";

        }
    }

    /*
        * Display all current taxonomy
        */
    $cpts = cpt_post_types() ?>
    <table class="widefat">
        <?php
        if ($cpts) {
            foreach ($cpts as $key => $cpt) {
                ?>
                <tr>
                    <td><?php //echo $key;?></td>
                    <td><?php echo $cpt;?></td>

                    <td><a href="admin.php?page=cpt_easy_mgmt/manage_cpt.php&cpt=<?php echo $key;?>&act=add_taxon">Add/Edit
                            taxonomies</a></td>
                    <td><a onclick="return confirm('Are you sure?')"
                           href="admin.php?page=cpt_easy_mgmt/manage_cpt.php&cpt=<?php echo $cpt;?>&act=del_cpt">Delete
                            This Post Type</a></td>
                </tr>
            <?php

            }
        }
        else { echo "<h2> You did not register any post type</h2>";}

        ?>
    </table>
    <?php //echo var_dump(get_option(cpt_easy_mgmt_taxonomy)); ?>
</div>