=== Custom Post Type Easy Management ===
Contributors: Asadullah khan
Tags: custome post type, easy management, cpt, taxonomies, management
Requires at least: 4.1
Tested up to: 4.5.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows to add custom post types with custome taxonomy.

== Description ==

Custom post types easy management allows to add you custom post types and taxonomies and easy way.    
   
Following features are present as of now.

*   Create new post type 
*   create new taxonomies 
*   delete post tyoe 
*   delete taxonomy 
 

More features to be added soon.

*   post type or taxonomy edit 
*   metaboxes for custom post type



== Upgrade Notice ==

 


== Installation ==

1.  Extract the zip file and just drop the contents in the wp-content/plugins/ directory
2.  Activate the plugin through the \'Plugins\' menu in WordPress. 
4.  Check under the admin section CPT Easy Management.


== Frequently Asked Questions ==



 
== Screenshots ==
1. coming soon


== Changelog ==


1.0


