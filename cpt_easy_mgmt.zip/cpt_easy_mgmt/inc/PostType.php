<?php
/*

This class will provide basic post type functionality


*/


class PostType{
	
	protected $name;	
	
	protected $singular;
	protected $plural;
	protected $labels;
	protected $options;
	protected $supports;	
	protected $messages;
	
	
	function __construct($name, $taxonomy=NULL, $args = array()){
		
		$this->labels = array(
					'name'			=> '%s', 
					'singular_name'	=> '%s', 
					'add_new'		=> 'Add New', 
					'add_new_item'  => 'Add New %s', 
					'edit_item'		=> 'Edit %s',
					'new_item'		=> 'New %s',
					'all_items'		=> 'All %s',
					'view_item'		=> 'View %s',
					'search_items'  => 'Search %s',
					'not_found'		=> 'No %s found',
					'not_found_in_trash'=> 'No %s found in Trash',
					'parent_item_colon' => '',
					'menu_name'		=> '%s'
				);
		 $this->options = array(
			//'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			//'rewrite'            => true,//array( 'slug' => 'book' ),
			'rewrite' 			 => array('slug' => $name,),
		//	'rewrite'			 => false, 
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 80,
			//'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
		  );		
		  
		$this->supports = array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' );	  
		
		$this->name = $name;
		$this->singular = $name;
		$this->plural = $name . 's';
		
		if($args['singular']) $this->singular = $args['singular'];
		if($args['plural']) $this->plural = $args['plural'];
		
		$this->labels['name'] 			= sprintf($this->labels['name'], ucwords($this->name));
		
		
		$this->labels['singular_name']  = sprintf($this->labels['singular_name'], ucwords($this->singular));
		$this->labels['add_new'] 		= sprintf($this->labels['add_new'], ucwords($this->name));
		$this->labels['add_new_item']   = sprintf($this->labels['add_new_item'], ucwords($this->singular));
		$this->labels['edit_item'] 		= sprintf($this->labels['edit_item'], ucwords($this->singular));
		$this->labels['new_item'] 		= sprintf($this->labels['new_item'], ucwords($this->singular));
		$this->labels['all_items'] 		= sprintf($this->labels['all_items'], ucwords($this->plural));
		$this->labels['view_item'] 		= sprintf($this->labels['view_item'], ucwords($this->singular));
		$this->labels['search_items']   = sprintf($this->labels['search_items'], ucwords($this->plural));
		$this->labels['not_found'] 		= sprintf($this->labels['not_found'], ucwords($this->plural));
		$this->labels['not_found_in_trash'] = sprintf($this->labels['not_found_in_trash'], ucwords($this->name));
		$this->labels['parent_item_colon'] = sprintf($this->labels['parent_item_colon'], ucwords($this->plural));
		$this->labels['menu_name'] 		= sprintf($this->labels['menu_name'], ucwords($this->name));
		
		$this->options['labels'] = $this->labels;
		$this->options['supports'] = $this->supports;

		add_action('init', array($this,'custom_flush_rules'));
		add_action('init', array($this, 'register'));

	}
	
	function remove_supports($item){
		$index = array_search($item, $this->supports);
		if($index>=0) unset($this->supports[$index]);
		else{
			$support = $this->supports;
			$support[] = $item;
			return $support;
		}
	}
	
	function get_label($index=NULL){
		if($index){
			if(isset($this->labels[$index])) return $this->labels[$index];	
		}
		return $this->labels;
	}
	
	function set_label($index, $value){
		if(isset($this->labels[$index])) return $this->labels[$index] = $value;
		return $this->labels; 
	}
	
	
	function get_option($index=NULL){
		if($index){
			if(isset($this->options[$index])) return $this->options[$index];	
		}
		return $this->options;
	}
	
	function set_option($index){
		if(isset($this->options[$index])) return $this->options[$index] = $value;
		return $this->options;		
	}
	
	function set_options($options){
		
	}
	
	function remove_option($index){
		if(isset($this->options[$index])) unset($this->options[$index]);
		else{
			$options = $this->options;
			$options[$index];
			return $options;
		}
	}
	
	
	function register(){
		$this->options['labels'] = $this->labels;
		$this->options['supports'] = $this->supports;
		register_post_type($this->name, $this->options);	
	}
	function custom_flush_rules(){
		//defines the post type so the rules can be flushed.
		$this->register();

		//and flush the rules.
		flush_rewrite_rules();
	}


}
