<?php

/*
 * Class taxonomy Registration
 */
class Taxonomy{
	protected $name;
	protected $singular;	
	protected $plural;
	protected $postType;
	protected $menu_name;
	
	protected $options = array();
	protected $labels = array();	
	
	/*
	 * Class Constructor
	 */
	function __construct($name, $post_types, $args = array()){
		$this->name = str_replace(" ","_",$name);
		$this->menu_name = $name;
		
		$this->labels = array(
				'name'                       =>  '%s',
				'singular_name'              => '%s',
				'search_items'               =>  'Search %s' ,
				'popular_items'              =>  'Popular %s' ,
				'all_items'                  =>  'All %s' ,
				'parent_item'                => null,
				'parent_item_colon'          => null,
				'edit_item'                  => 'Edit %s' ,
				'update_item'                => 'Update %s' ,
				'add_new_item'               =>  'Add New %s' ,
				'new_item_name'              =>  'New %s Name' ,
				'separate_items_with_commas' =>  'Separate %s with commas' ,
				'add_or_remove_items'        =>  'Add or remove %s' ,
				'choose_from_most_used'      =>  'Choose from the most used %s' ,
				'not_found'                  => 'No %s found.' ,
				'menu_name'                  =>  $this->menu_name ,
				
			);	
		
		
		
		foreach($this->labels as $index => $value){
			$this->labels[$index] = sprintf($value, ucwords($this->name));
		}
		//'rewrite'               => array( 'slug' => 'writer' ),
		
		$this->postType = $post_types;
		
		$this->options = array(
			'hierarchical'          => true,
			'labels'                => $this->labels,
			'show_ui'               => true,
			'show_admin_column'     => true,
			'update_count_callback' => '_update_post_term_count',
			'query_var'             => true,
			'rewrite'               => array( 'slug' => $name, ),
		);
		
		$this->options['labels'] = $this->labels;
		
		//$this->options['rewrite'] = array( 'slug' => true );
		
		add_action('init', array($this, 'register'));
	}
	
	function get_label($index=NULL ){
		if($this->labels[$index]) return $this->labels[$index];
		return $this->labels; 		
	}
	
	function set_label($index, $value){
		if($this->labels[$index]) return $this->labels[$index] = $value;
		else {
			$labels = $this->labels; 	
			$labels[$index] = NULL;
			return $labels;	
		}		
	}
	
	function set_labels($labels){
		foreach($labels as $index => $value){
			if($this->labels[$index]) $this->labels[$index] = $value;		
			else $not_found[$index] = $value;
		}
		return $not_found;
	}

	function get_option($index=NULL ){
		if($this->options[$index]) return $this->options[$index];
		return $this->options; 		
	}
	
	function set_option($index, $value){
		if($this->options[$index]) return $this->options[$index] = $value;
		else {
			$options = $this->options; 	
			$options[$index] = NULL;
			return $options;	
		}		
	}
	
	function set_options($options){
		foreach($options as $index => $value){
			if($this->options[$index]) $this->options[$index] = $value;		
			else $not_found[$index] = $value;
		}
		return $not_found;
	}

	function remove_options($index){
		if($this->options[$index]) unset($this->options[$index]);
		return $this->options;
	}
	
	function __set($var, $value){
		switch($var){
			case 'singular':
			
			break;
			
			case 'plural':
			
			break;
			
			default:			
				return false;	
			break;
		}
		
		$this->{$var} = $value;
	}
	
	function __toString(){
		return $this->name;		
	}
	
	function register(){
		$this->options['labels'] = $this->labels;
		
		register_taxonomy( $this->name, $this->postType, $this->options ); 
	}
	
	
}
