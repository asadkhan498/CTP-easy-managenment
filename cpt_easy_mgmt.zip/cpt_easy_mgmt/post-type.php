<?php
/****
 * Plugin Name: TCU Post Types
 * Description: This plugin will enable you to create post types and Taxonomies instantly
 * Author: Asad K
 *
 * Version: 1.0
 ****/

require_once('inc/PostType.php');
require_once('inc/Taxonomy.php');
/*
 * Creating Administration Menus
 */
function cpt_easy_menu()
{
    add_menu_page(
        'CPT Easy Management',
        'CPT Easy Management',
        'manage_options',
        'cpt_easy_mgmt/manage_cpt.php',
        '',
        '',
        6
    );
    add_submenu_page(
        'cpt_easy_mgmt/manage_cpt.php',
        'Add New Post Typet',
        'Add New',
        'manage_options',
        'cpt_easy_mgmt/add_cpt.php',
        ''

    );
}

add_action('admin_menu', 'cpt_easy_menu');

$cpts = get_option('cpt_easy_mgmt');

/*
 * Register new Post type
 */
if ($cpts) {
    foreach ($cpts as $cpt) {
        new PostType($cpt);
    }
}


/*
 * Register new Taxonomy
 *
 */

$cpt_taxonomies = get_option('cpt_easy_mgmt_taxonomy');


if ($cpt_taxonomies) {
    foreach ($cpt_taxonomies as $cpt_taxonomy) {
        foreach ($cpt_taxonomy as $key => $cpt_t) {
            new Taxonomy($cpt_t, $cpts[$key]);

        }

    }
}



	